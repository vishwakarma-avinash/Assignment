package com.yash.junit5;
import java.util.Arrays;

public class ArrayOperation {

	public int[] sortArray(int[] arrayInput) {
		Arrays.sort(arrayInput);
		return arrayInput;
	}
	
}

