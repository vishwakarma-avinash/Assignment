package com.yash.junit5;

public class Calculator {

	public int computeDivision(int no1, int no2) {
		if(no2!=0) {
			return no1/no2;			
		}
		return 0;
	}
	
}