package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.yash.dao.JDBCEmployeesDAOImpl;
import com.yash.entities.Employees;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

class TestJDBCEmployeesDAOImplIntegration {

	@Spy
	private ConnectionManager manager;
	@InjectMocks
	private JDBCEmployeesDAOImpl jdbcEmployeesDAOImpl;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}


	@Test
	void testgetAllEmployeesWhenReturnedListSizeIsGreaterThanZero() {
     try {
		List<Employees> employeesList=jdbcEmployeesDAOImpl.getAllEmployees();
		assertTrue(employeesList.size()>0);
	} catch (DAOException e) {
		assertFalse(true);
	}   
	}


}
