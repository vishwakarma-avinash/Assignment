/*
  Retrieve JobTitle of employee based on employeeId using stored procedure. 
  Execute stored procedure from java. */

package com.yash.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.yash.entity.Employees;

public class ReterieveJobIdUsingEmployeeId {
	public static void main(String[] args) throws SQLException, IOException {

		File file=new File("C:\\Users\\aman.lashkari\\Documents\\workspace-spring-tool-suite-4-4.7.1.RELEASE\\Assignment_29-10-2021\\src\\main\\resources\\db.properties");
		Properties properties=new Properties();
		try(
			InputStream inStream=new FileInputStream(file);	
			){
			properties.load(inStream);
		}catch(IOException e) {
			e.printStackTrace();
		}
		try {
			Class.forName(properties.getProperty("driver"));
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		}
		Employees employee=new Employees();
		List<Employees> employeeList= new ArrayList<>();
		
		
		
		Scanner scanner=new Scanner(System.in);
		Connection con=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"),properties.getProperty("password"));
		
		System.out.print("Enter Department ID:");
		int department_id=0;
		department_id=scanner.nextInt();
		
		con.setAutoCommit(false);
		
		PreparedStatement Statement=con.prepareStatement("select * from employees where department_id=?");
		
		
		Statement.setInt(1, department_id);
		
		//Executing Query
		ResultSet resultSet=Statement.executeQuery();
		
		//Fetching rows from database table
		while(resultSet.next()) {
			
		
	
}
	
	}
}

