package com.yash.demo;

import java.io.File;
import java.io.FileInputStream;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Properties;
import java.util.Scanner;

import com.yash.entity.Jobs;

public class InsertRecordInJobTable {
	
	public static void main(String[] args) throws ClassNotFoundException {
		File file=new File("C:\\Users\\aman.lashkari\\Documents\\workspace-spring-tool-suite-4-4.7.1.RELEASE\\JDBCApplication\\src\\main\\resources\\db.properties");
		Properties properties=new Properties();
		try(
			InputStream is=new FileInputStream(file);	
				){
			properties.load(is);

		} catch (IOException e) {
		
			e.printStackTrace();
		}
		Class.forName(properties.getProperty("driver"));
		Jobs job=new Jobs();
		int rows=0;
		try(
			Scanner scanner=new Scanner(System.in);
			Connection con=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"),properties.getProperty("password"));
				 ){
			System.out.print("Job Id:");
			if(scanner.hasNext()) {
				job.setJobId(scanner.next());
			}
			System.out.print("Job Title:");
			if(scanner.hasNext()) {
				job.setJobTitle(scanner.next());
			}
			System.out.print("Minimum Salary");
			if(scanner.hasNextDouble()) {
				job.setMinSalary(scanner.nextDouble());
			}
			System.out.print("Maximum Salary");
			if(scanner.hasNextDouble()) {
				job.setMaxSalary(scanner.nextDouble());
			}
			PreparedStatement statement=con.prepareStatement("insert into jobs values(?,?,?,?)");
			statement.setString(1, job.getJobId());
			statement.setString(2, job.getJobTitle());
			statement.setDouble(3, job.getMinSalary());
			statement.setDouble(4, job.getMaxSalary());
			rows=statement.executeUpdate();
		}catch(InputMismatchException | SQLException e) {
			e.printStackTrace();
		}
		if(rows>0) {
			System.out.println("Insert was successful");
		}
	}
}

		



