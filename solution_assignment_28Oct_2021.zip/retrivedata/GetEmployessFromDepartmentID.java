package com.yash.retrivedata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.yash.entity.Employees;

public class GetEmployessFromDepartmentID {

	public static void main(String[] args) {

		List<Employees> employeeList = new ArrayList<Employees>();
		Employees employee=new Employees();
		Scanner userInput = new Scanner(System.in);
		int dept_id=0;
	try {
		//Loading Driver Class
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	
	//Creating Connection to database
			Connection connection=null;
			try {
				connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hr","root","root");
				
				//Creating SQL Statement
				PreparedStatement preparedStatement=connection.prepareStatement("select * from employees where department_id=?");
				
				System.out.print("Enter Department ID:");
				
				dept_id=userInput.nextInt();
				preparedStatement.setInt(1, dept_id);
				
				//Executing Query
				ResultSet resultSet=preparedStatement.executeQuery();
				
				//Fetching rows from database table
				while(resultSet.next()) {
				
					//Setting data in Employee entitiy class
					employee.setEmployeeId(resultSet.getInt("employee_id"));
					employee.setFirstName(resultSet.getString("first_name"));
					employee.setLastName(resultSet.getString("last_name"));
					employee.setEmail(resultSet.getString("email"));
					employee.setPhoneNumber(resultSet.getString("phone_number"));
					employee.setHireDate(resultSet.getDate("hire_date").toLocalDate());
					employee.setJobId(resultSet.getString("job_id"));
					employee.setSalary(resultSet.getDouble("salary"));
					employee.setCommissionPCT(resultSet.getDouble("commission_pct"));
					employee.setManagerId(resultSet.getInt("manager_id"));
					employee.setDepartmentId(resultSet.getInt("department_id"));
					employeeList.add(employee);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			System.out.println(employee);
}
	
}
