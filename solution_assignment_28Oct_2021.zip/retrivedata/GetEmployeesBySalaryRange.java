package com.yash.retrivedata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.yash.entity.Employees;

public class GetEmployeesBySalaryRange {

	public static void main(String[] args) {
		List<Employees> employeeList = new ArrayList<Employees>();
		Employees employee=new Employees();
		
		double max_salary=0.0, min_salary=0.0;
	try {
		//Loading Driver Class
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	
	//Creating Connection to database
			Connection connection=null;
			try {Scanner userInput = new Scanner(System.in);
				connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hr","root","root");
				
				//Creating SQL Statement
				PreparedStatement preparedStatement=connection.prepareStatement("select * from employees where salary between ? and ?");
				
				System.out.print("Enter maximum range:");
				
				max_salary=userInput.nextDouble();
				
				System.out.print("Enter minimum range:");
				
				max_salary=userInput.nextDouble();
				preparedStatement.setDouble(1, min_salary);
				preparedStatement.setDouble(2, max_salary);
				
				//Executing Query
				ResultSet resultSet=preparedStatement.executeQuery();
				
				//Fetching rows from database table
				while(resultSet.next()) {
				
					//Setting data in Employee entitiy class
					employee.setEmployeeId(resultSet.getInt("employee_id"));
					employee.setFirstName(resultSet.getString("first_name"));
					employee.setLastName(resultSet.getString("last_name"));
					employee.setEmail(resultSet.getString("email"));
					employee.setPhoneNumber(resultSet.getString("phone_number"));
					employee.setHireDate(resultSet.getDate("hire_date").toLocalDate());
					employee.setJobId(resultSet.getString("job_id"));
					employee.setSalary(resultSet.getDouble("salary"));
					employee.setCommissionPCT(resultSet.getDouble("commission_pct"));
					employee.setManagerId(resultSet.getInt("manager_id"));
					employee.setDepartmentId(resultSet.getInt("department_id"));
					employeeList.add(employee);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			System.out.println(employee);
}

	}

