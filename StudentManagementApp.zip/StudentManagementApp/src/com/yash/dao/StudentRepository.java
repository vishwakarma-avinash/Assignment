package com.yash.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.yash.entity.Student;
import com.yash.view.MainView;

public class StudentRepository {
	
	static List<Student> studentRecord= new ArrayList<>();
	Scanner input = new Scanner(System.in);
	
	public void registerStudent()
	{
		System.out.print("Student Registration");
		
		System.out.print("Enter First Name :");
		String fname= input.next();
		
		System.out.print("Enter Last Name :");
		String lname= input.next();
		
		System.out.print("Enter Date of birth :");
		String dob= input.next();
		
		System.out.print("Enter gender :");
		String gender= input.next();
		
		System.out.print("Enter Course :");
		String course= input.next();
		
		Student student =new Student();
		
		student.setStudentFirstName(fname);
		student.setStudentLastName(lname);
		student.setStudentDob(dob);
		student.setStudentGender(gender);
		student.setStudentCourse(course);
		
		studentRecord.add(student);
		System.out.println("Student Registered");
		System.out.println("\n");
		
		MainView mvObj =new MainView();
		mvObj.mainMenu();
	}
	
	public static void viewStudent()
	{
		int count=1;
		for(Student obj: studentRecord)
		System.out.println("1000" + count + obj);
		count++;
	}
	public void updateStudent()
	{
		
	}
	
	public void removeStudent()
	{
		System.out.println("Enter student ID to be removed");
		int id=input.nextInt();
		studentRecord.remove(id);
	}
	
	public void exitMainMenu()
	{
		System.exit(0);
	}
}
