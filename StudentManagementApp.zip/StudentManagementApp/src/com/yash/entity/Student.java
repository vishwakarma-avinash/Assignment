package com.yash.entity;

import java.util.Objects;

public class Student {

	private int studentId;
	private String studentFirstName;
	private String studentLastName;
	private String studentDob;
	private String studentGender;
	private String studentCourse;
	
	
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentFirstName() {
		return studentFirstName;
	}

	public void setStudentFirstName(String studentFirstName) {
		this.studentFirstName = studentFirstName;
	}

	public String getStudentLastName() {
		return studentLastName;
	}

	public void setStudentLastName(String studentLastName) {
		this.studentLastName = studentLastName;
	}

	public String getStudentDob() {
		return studentDob;
	}

	public void setStudentDob(String studentDob) {
		this.studentDob = studentDob;
	}

	public String getStudentGender() {
		return studentGender;
	}
	public void setStudentGender(String gender) {
		this.studentGender = gender;
	}
	public String getStudentCourse() {
		return studentCourse;
	}
	public void setStudentCourse(String studentCourse) {
		this.studentCourse = studentCourse;
	}
	@Override
	public int hashCode() {
		return Objects.hash(studentCourse, studentDob, studentFirstName, studentGender, studentId, studentLastName);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Objects.equals(studentCourse, other.studentCourse) && Objects.equals(studentDob, other.studentDob)
				&& Objects.equals(studentFirstName, other.studentFirstName) && studentGender == other.studentGender
				&& studentId == other.studentId && Objects.equals(studentLastName, other.studentLastName);
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentFirstName=" + studentFirstName + ", studentLastName="
				+ studentLastName + ", studentDob=" + studentDob + ", studentGender=" + studentGender
				+ ", studentCourse=" + studentCourse + "]";
	}
}
