package com.yash.factory;

import com.yash.DAO.AuthUserDAO;
import com.yash.DAO.memoryAuthImpl;

public class UserDAo {
	public static AuthUserDAO getInstance() {
		AuthUserDAO authUserDAO=new memoryAuthImpl();
		return authUserDAO;
}
}