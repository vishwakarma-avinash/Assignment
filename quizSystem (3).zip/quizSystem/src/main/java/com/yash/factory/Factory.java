package com.yash.factory;

import javax.xml.parsers.ParserConfigurationException;

import com.yash.createXML.collectionOfJava;
import com.yash.createXML.exceptionOfJava;

public class Factory
{
    
	@SuppressWarnings("static-access")
	public  void factory() throws ParserConfigurationException, Throwable 
    {
    	
    	collectionOfJava collection= new collectionOfJava();
    	collection.createCollection();
    	
    	exceptionOfJava exception=new exceptionOfJava();
    	exception.createException();
    }
}