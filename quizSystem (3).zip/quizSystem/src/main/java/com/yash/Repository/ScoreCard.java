package com.yash.Repository;
import com.yash.entity.User;


public class ScoreCard {
	
	User user = new User();
	private String userName=user.getUserName();
	public String getScoreCard(double score)
	{
	
	System.out.println("**************************************************************");
	System.out.println("Thank you for participating in Test");
	System.out.println("Here is your scorecard......");
	
	System.out.println("\n");
	System.out.println("Name: "+userName);
	if(score>55.0)
	{
		System.out.println("Congrtulation "+userName+", you have passed this test");
		System.out.println("Your score is "+score);
	}
	else
	{
		System.out.println("Sorry "+userName+", you have not cleared test");
	    System.out.println("Your score is "+score);
	}
	System.out.println("****************************************************************");
	
	String result=getScoreCard(score);
	return result;
}
}