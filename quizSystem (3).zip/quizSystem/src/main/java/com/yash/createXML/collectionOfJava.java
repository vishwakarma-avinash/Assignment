package com.yash.createXML;

import java.io.File;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class collectionOfJava 
{
	private static final Logger LOGGER = LoggerFactory.getLogger(collectionOfJava .class);
	
	public static void createCollection()
	{ 
		 DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder;
	        try {
	            dBuilder = dbFactory.newDocumentBuilder();
	            Document doc = dBuilder.newDocument();
	            
	            Element rootElement = doc.createElement("CollectionOfJava");

	            doc.appendChild(rootElement);
                rootElement.appendChild(createUserElement(doc, "1", "Which of these standard collection classes implements a dynamic array?", "ArrayList", "LinkedList", "AbstractList","AbstractSet","ArrayList"));
                rootElement.appendChild(createUserElement(doc, "2", "Which of these class can generate an array which can increase and decrease in size automatically?", "DynamicList()", "LinkedList()", "ArrayList()","ArraySet()","LinkedList()"));
                rootElement.appendChild(createUserElement(doc, "3", "Which of these method can be used to increase the capacity of ArrayList object manually?", "IncreaseCapacity", "DecreaseCapacity", "capacity","ensureCapacity","ensureCapacity"));
                rootElement.appendChild(createUserElement(doc, "4", "Which of these method of ArrayList class is used to obtain present size of an object?", "Index()", "Size()", "Capacity()","Length()","Index()"));
                rootElement.appendChild(createUserElement(doc, "5", "Which of these methods can be used to obtain a static array from an ArrayList object?", "Array()", "toArray()", "convertArray()","convertToArray()","convertArray()"));
                rootElement.appendChild(createUserElement(doc, "6", "Which of these method is used to reduce the capacity of an ArrayList object?", "Trim()", "TrimCapacity()", "TrimToSize()","TrimSize()","TrimToSIze()"));
                rootElement.appendChild(createUserElement(doc, "7", "Map implements collection interface?", "False", "True", " "," ","False"));
                rootElement.appendChild(createUserElement(doc, "8", "Is hashMap an ordered collection?", "True", "False", " "," ","False"));
                rootElement.appendChild(createUserElement(doc, "9", " Which of the below does not implement Map interface?", "Enum", "Vector", "HashTable","HashMap","Vector"));
                rootElement.appendChild(createUserElement(doc, "10", "How can we remove an object from ArrayList?", "remove() method and using Iterator", "using iterator", "remove() method","delete() method","remove() method and using Iterator"));
                
    
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
	            Transformer transformer = transformerFactory.newTransformer();
	            
	            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	            DOMSource source = new DOMSource(doc);

	            StreamResult file = new StreamResult(new File("D:\\JAVATrainingWorkspace\\quizSystem\\src\\main\\resources\\CollectionsOfJava.xml"));

	            transformer.transform(source, file);

	        } catch (Exception e) {
	            e.printStackTrace();
	            LOGGER.error("Failed due to : "+e.getMessage()+e);
	            
	        }
	    }

private static Element createUserElement(Document doc, String Id, String Questions , String Option1 , String Option2,
     String Option3,String Option4,String Correct)
 {
     Element data = doc.createElement("Question");

     data.appendChild(createUserElements(doc, data, "Id", Id));
     
     data.appendChild(createUserElements(doc, data, "Questions", Questions));

     data.appendChild(createUserElements(doc, data, "Option1", Option1));

     data.appendChild(createUserElements(doc, data, "Option2", Option2));

     data.appendChild(createUserElements(doc, data, "Option3", Option3));
     
     data.appendChild(createUserElements(doc, data, "Option4", Option4));
     
     data.appendChild(createUserElements(doc, data, "Correct", Correct));

     return data;
 }

 
private static Element createUserElements(Document doc, Element element, String name, String value) 
 {
     Element node = doc.createElement(name);
     node.appendChild(doc.createTextNode(value));
     return node;
 }


}