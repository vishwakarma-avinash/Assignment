package com.yash.DAO;

public interface AuthUserDAO {
	public boolean authUser(String userName,String password);
}
