package com.yash.service;

import com.yash.DAO.AuthUserDAO;
import com.yash.exception.AuthenticationException;
import com.yash.factory.UserDAo;
import com.yash.model.UserModel;

public class AuthServiceImpl implements AuthService {

	private AuthUserDAO authUserDAO;
	public AuthServiceImpl() {
		this.authUserDAO=UserDAo.getInstance();
	}
	public UserModel authService(UserModel userModel) throws AuthenticationException {	
		boolean authenticated=authUserDAO.authUser(userModel.getUserName(), userModel.getPassword());
		if(authenticated) {
			userModel.setAuthenticated(true);
			return userModel;
		}else {
			throw new AuthenticationException("username or password do not match in records..");
		}
		
	}

}
