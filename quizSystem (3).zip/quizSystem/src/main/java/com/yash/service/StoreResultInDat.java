package com.yash.service;
import com.yash.DAO.Display;
import com.yash.Repository.ScoreCard;
import java.io.FileWriter;  
public class StoreResultInDat { 
	
	ScoreCard scoreCard = new ScoreCard();
    public void storeResult(String result)
    {     
         try{    
           FileWriter fw=new FileWriter("D:\\JAVATrainingWorkspace\\quizSystem\\src\\test\\resources\\ScoreCard.dat");    
           fw.write(result);    
           fw.close();    
          }catch(Exception e)
         {
        	  System.out.println(e);
         }    
          System.out.println("Success...");    
     }    
}  