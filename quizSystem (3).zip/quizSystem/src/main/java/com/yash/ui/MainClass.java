package com.yash.ui;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.PropertyConfigurator;

import com.yash.Repository.Repository;
import com.yash.factory.Factory;

public class MainClass {
		
		@SuppressWarnings("static-access")
		public static void main(String[] args) throws ParserConfigurationException, Throwable{
			
			String log4jConfPath = "D:\\JAVATrainingWorkspace\\quizSystem\\src\\main\\resources\\log4j.properties";
			PropertyConfigurator.configure(log4jConfPath);

			//BasicConfigurator.configure();
			Factory factory = new Factory();
			  factory.factory();
			
			Repository repo=new Repository();
	          repo.readCollection();
	          repo.readException();
  
	        UI uiclass = new UI();
	         uiclass.ui();       
	}
}

