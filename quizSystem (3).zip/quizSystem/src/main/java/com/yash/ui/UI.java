package com.yash.ui;

import com.yash.view.LoginView;

public class UI {
	
	public void ui() throws Exception {
	
				LoginView logindata=new LoginView();
				logindata.logindata();     	
			}
}


