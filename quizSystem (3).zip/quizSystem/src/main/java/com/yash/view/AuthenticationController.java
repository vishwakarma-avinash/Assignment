package com.yash.view;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yash.exception.AuthenticationException;
import com.yash.factory.AuthServiceDAo;
import com.yash.model.UserModel;
import com.yash.service.AuthService;

public class AuthenticationController {
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationController.class);
	private AuthService authService;
	public AuthenticationController() {
		this.authService=AuthServiceDAo.getInstance();
	}
	public void authUser(UserModel userModel) throws Exception{
		try {
			UserModel user=authService.authService(userModel);
			WelcomeView welcomeView=new WelcomeView();
			welcomeView.welcomeUser(user);
			
		} catch (AuthenticationException e) {

			ErrorView errorView=new ErrorView();
			errorView.authError();
			LOGGER.error("Failed due to : "+e.getMessage()+e);
		}
	}
}
