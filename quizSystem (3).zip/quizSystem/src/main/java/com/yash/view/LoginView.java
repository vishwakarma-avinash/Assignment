package com.yash.view;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yash.model.UserModel;

public class LoginView {
	private static final Logger LOGGER = LoggerFactory.getLogger(LoginView.class);
	
	public void logindata() throws Exception {
		
	try(
			Scanner scanner=new Scanner(System.in);		
		  ){
			System.out.println("================WELCOME TO THE QUIZ==================");
			System.out.println("\nEnter Username and Password-->");
			System.out.print("UserName:");
			String userName=scanner.next();
			
			System.out.print("Password:");
			String password=scanner.next();
			
			UserModel userModel=new UserModel();
			userModel.setUserName(userName);
			userModel.setPassword(password);
			
			AuthenticationController controller=new AuthenticationController();
			controller.authUser(userModel);
			
		
			}catch(InputMismatchException e) {
			
			System.err.println("Invalid input");
			LOGGER.error("Failed due to : "+e.getMessage()+e);
			

			}
	}
}