package com.yash.ui;

import java.util.Scanner;

import com.yash.DAO.Display;

public class UI {
	
	public void ui() throws Throwable{
				
				
				@SuppressWarnings("resource")
				Scanner scan=new Scanner(System.in);
				String sp=" ";
				System.out.println("================WELCOME TO THE QUIZ==================");
				System.out.print("Enter Username: ");
				String username=scan.nextLine();
				
				if((username.contains(sp)) || username.length()<4) {
					System.out.println("Invalid Username");
					return;
				}
				
				System.out.print("Enter Password: ");
				String pass=scan.nextLine();
				if((pass.contains(sp)) || pass.length()<5) {
					System.out.println("Invalid Password");
					return;
				}
					System.out.println(username+" you are Registered Successfully");
				
					System.out.print("Enter the Username: ");
			        String uname = scan.nextLine();
			        System.out.print("Enter the Password: ");
			        String upass = scan.nextLine();	
			        
			    if(username.equals(uname) && pass.equals(upass)){
			            System.out.println("Welcome "+uname+" you have Logged-in Successfully");
			        }
			        else{
			            System.out.println("Username or password Mismatch");
			        }
			    
			    if(username.equals(uname) && pass.equals(upass)){
			    	System.out.println("\n========Welcome to the Quiz========");
				
			    	System.out.println("Select Topic of the test----->");
			    	System.out.println("1- Collections of JAVA");
			    	System.out.println("2- Exception Handling of JAVA");	
			    }
			
			    Display display = new Display();
			    display.displayQuestion();  
		
	}
}

