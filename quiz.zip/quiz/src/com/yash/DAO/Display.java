package com.yash.DAO;

import java.util.Scanner;

import com.yash.Repository.Question;
import com.yash.Repository.Repository;

public class Display extends Repository {
	
	Scanner sc = new Scanner(System.in);
	int ans;
	int count;
	int i=1;

	public void displayQuestion()
    {  
		Repository repo=new Repository();
		Scanner sc = new Scanner(System.in);
    	int input = sc.nextInt();
    	switch(input)
    	{
    		case 1:  
    			for (Question Q:repo.CollectionsOfJava)
    	    {
    				
    		         System.out.println("==========================");
                     System.out.println("Question:"+" i "+Q.getQuestion());
                     System.out.println(" "+Q.getOption1());
                     System.out.println(" "+Q.getOption2());
                     System.out.println(" "+Q.getOption3());
                     System.out.println(" "+Q.getOption4());
                     System.out.println();
                    
                     System.out.println("Enter Your Answer and press Enter: ");
                     ans = sc.nextInt();
                     
                          switch(ans) 
                          {
                             case 1: if(Q.getOption1().equals(Q.getCorrect())) {
            	                                count++;
                                             }
                             case 2: if(Q.getOption2().equals(Q.getCorrect())) {
                                                 count++;
                                             }
                             case 3: if(Q.getOption3().equals(Q.getCorrect())) {
                                                 count++;
                                             }
                             case 4: if(Q.getOption4().equals(Q.getCorrect())) {
                                                 count++;      
                             				 }    
                          }		    
                          i++;
                          Q.getQuestion();
    	    }
    	              System.out.println("================Test End=================");
    	              System.out.println("Your Score is:  "+(count*10)+ "%" );
    	              break;
		case 2:  
    		  for (Question Q:repo.ExceptionsOfJava )
    		  {
		          System.out.println("=========================");
                  System.out.println("Question:"+ i +" "+Q.getQuestion());
                  System.out.println(" "+Q.getOption1());
                  System.out.println(" "+Q.getOption2());
                  System.out.println(" "+Q.getOption3());
                  System.out.println(" "+Q.getOption4());
                  System.out.println();

                  System.out.println("Enter Your Answer and press Enter: ");
                  ans = sc.nextInt();
                  switch(ans) 
                   {
                    case 1: if(Q.getOption1().equals(Q.getCorrect())) {
                                 count++;
                               }
                    case 2: if(Q.getOption2().equals(Q.getCorrect())) {
                                 count++;
                               }
                    case 3: if(Q.getOption3().equals(Q.getCorrect())) {
                                 count++;
                               }
                    case 4: if(Q.getOption4().equals(Q.getCorrect())) {
                                 count++;
                               }	
                   }
                  		i++;       
    		  }   
	           System.out.println("=======================Test End============================");
               System.out.println("Your Score is: " +(count*10)+ "%");
               break;
    	}
    }
}
    
    

	
	    		
		
 

