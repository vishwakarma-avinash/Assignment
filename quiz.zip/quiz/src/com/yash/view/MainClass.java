package com.yash.view;

import javax.xml.parsers.ParserConfigurationException;


import com.yash.Repository.Repository;
import com.yash.ui.UI;

public class MainClass {
		
		public static void main(String[] args) throws ParserConfigurationException, Throwable{
			
			Repository repo=new Repository();
	          repo.readCollectionOfJava();
	          repo.readExceptionOfJava();
	          
	        UI uiclass = new UI();
	         uiclass.ui();       
	}
}

