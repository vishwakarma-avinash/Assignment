package com.yash.Repository;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Repository{
	
		public static List<Question>  CollectionsOfJava;
		public static List<Question>  ExceptionsOfJava;
		
		public static List readCollectionOfJava()
		{
			String filepath= "D:\\JAVATrainingWorkspace\\quiz\\quiz\\src\\CollectionOfJava.xml";
			File xmlfile=new File(filepath);
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance(); 
			DocumentBuilder db;
			
			try {
				db=dbf.newDocumentBuilder(); 
				Document doc = db.parse(xmlfile);  
				doc.getDocumentElement().normalize();  
				NodeList nodeList = doc.getElementsByTagName("CollectionOfJava");
				CollectionsOfJava = new ArrayList<Question>();
		
				for (int i = 0; i < nodeList.getLength(); i++)   
				{  
					CollectionsOfJava.add(get(nodeList.item(i)));
				}
				
			}catch (SAXException | ParserConfigurationException | IOException   e)
			{
				e.printStackTrace();
			}
			return CollectionsOfJava;
			
		}	
	
		public static List readExceptionOfJava(){
			
			String filepath="D:\\JAVATrainingWorkspace\\quiz\\quiz\\src\\ExceptionOfJava.xml";
			File xmlfile=new File(filepath);
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance(); 
			DocumentBuilder db;
		
		try {
			db =dbf.newDocumentBuilder();
			Document doc = db.parse(xmlfile);  
			doc.getDocumentElement().normalize();  
			NodeList nodeList = doc.getElementsByTagName("ExceptionOfJava");
			ExceptionsOfJava = new ArrayList <Question> ();
			
			for (int i = 0; i < nodeList.getLength(); i++)   
			{  
				ExceptionsOfJava.add(get(nodeList.item(i)));
			}
		 	}catch (SAXException | ParserConfigurationException | IOException  e){
	        e.printStackTrace();
	    	}
			return ExceptionsOfJava;
		}		

		 private static Question get(Node node) {
		    
		        Question Que = new Question();
		        if (node.getNodeType() == Node.ELEMENT_NODE) {
		            Element element = (Element) node;
		            Que.setId(Integer.parseInt(getTagValue("Id", element)));
		            Que.setQuestion(getTagValue("question", element));
		            Que.setOption1(getTagValue("option1", element));
		            Que.setOption2(getTagValue("option2", element));
		            Que.setOption3(getTagValue("option3", element));
		            Que.setOption4(getTagValue("option4", element));
		            Que.setCorrect(getTagValue("correct", element));
		        }
		        return Que;
		    }
		 private static String getTagValue(String tag, Element element) {
		        NodeList nodeList = element.getElementsByTagName(tag).item(0).getChildNodes();
		        Node node = (Node) nodeList.item(0);
		        return node.getNodeValue();
		    }
}
